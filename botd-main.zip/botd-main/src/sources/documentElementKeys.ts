export default function getDocumentElementKeys(): string[] {
  return document.documentElement.getAttributeNames()
}
