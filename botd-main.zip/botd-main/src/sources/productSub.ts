export default function getProductSub(): string {
  return navigator.productSub
}
