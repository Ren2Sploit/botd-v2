export default function getWindowOuterSize(): number[] {
  return [window.outerWidth, window.outerHeight]
}
