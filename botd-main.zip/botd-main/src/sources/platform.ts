export default function getPlatform(): string {
  return navigator.platform
}
