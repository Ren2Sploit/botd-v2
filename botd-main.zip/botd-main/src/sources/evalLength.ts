export default function getEvalLength(): number {
  return eval.toString().length
}
