export default function getUserAgent(): string {
  return navigator.userAgent
}
