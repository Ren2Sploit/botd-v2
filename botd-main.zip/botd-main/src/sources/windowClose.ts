export default function getWindowClose(): string {
  return window.close.toString()
}
