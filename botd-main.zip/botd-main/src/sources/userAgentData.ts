export default function hasUserAgentData(): boolean {
  return navigator.userAgentData !== undefined
}
