export default function getTimestamp(): number {
  return Date.now()
}
