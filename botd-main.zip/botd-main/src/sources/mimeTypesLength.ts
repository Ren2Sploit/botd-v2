export default function getMimeTypesLength(): number {
  return navigator.mimeTypes.length
}
