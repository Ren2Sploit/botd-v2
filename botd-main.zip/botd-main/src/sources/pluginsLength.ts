export default function getPluginsLength(): number {
  return navigator.plugins.length
}
