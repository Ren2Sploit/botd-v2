export default function getScreen(): number[] {
  return [screen.width, screen.height]
}
