export default function getAppVersion(): string {
  return navigator.appVersion
}
